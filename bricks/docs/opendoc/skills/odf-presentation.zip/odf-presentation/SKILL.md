---
name: odf-presentation
description: Creates OpenDocument presentations (.odp) and PowerPoint (.pptx) or PDF slide decks from them, with title slides, bullets, images and speaker notes. Use when asked for slides, a deck, a presentation or a pitch.
---

# OpenDocument presentations

Tools from the `docs:opendoc` brick: `ReadDocument`, `ConvertDocument`. The script runs with `/opt/odf/bin/python` (needs a shell tool such as `Bash`).

## Build a deck: JSON spec + make_odp.py

```sh
/opt/odf/bin/python /trefoil/skills/odf-presentation/scripts/make_odp.py deck.json out.odp
```

```json
{
  "theme": {"background": "#ffffff", "text": "#1f2933", "accent": "#2b6cb0", "font": "Liberation Sans"},
  "slides": [
    {"title": "Quarterly review", "subtitle": "Q3 2026"},
    {"title": "Highlights", "bullets": ["Revenue up 12%", ["EU +18%", "US +7%"], "Two new customers"],
     "notes": "Mention the EU launch first."},
    {"title": "Architecture", "text": "How requests flow", "image": "/workspace/out/diagram.png"},
    {"title": "Growth", "bullets": ["Steady month on month", "Best in October"], "image": "/workspace/out/chart.png"}
  ]
}
```

- Title slide: only `title` (+ `subtitle`).
- `bullets`: strings; a nested list holds sub-bullets of the item before it. `text`: a paragraph or list of paragraphs above the bullets.
- `image`: PNG or JPEG path. With bullets it fills the right half; otherwise it fills the slide under the title and text. It keeps its aspect ratio.
- `notes`: speaker notes.
- Slides are 16:9. `theme` is optional; `accent` colours titles.

## Writing good slides

- One idea per slide; the title says the point ("Revenue grew 12%", not "Revenue").
- At most ~6 bullets of ~8 words; put detail in `notes`.
- Charts and diagrams beat tables: render them to PNG first (e.g. matplotlib with a Python tool, or a chart/diagram tool) and use `image`.
- Open with a title slide, close with a summary or next steps.

## Export and check

1. `ConvertDocument format=pptx` for PowerPoint users, `format=pdf` to share.
2. `ReadDocument` the `.odp` (or `.pptx`) to check every slide's text and the notes.
3. Save the files the user asked for (e.g. `SaveArtifact`).

To read or summarise an existing deck (`.odp`, `.pptx`, `.ppt`), use `ReadDocument`: it lists slides with their text and notes.
