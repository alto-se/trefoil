"""Builds an OpenDocument presentation (.odp) from a JSON spec.

    /opt/odf/bin/python make_odp.py spec.json out.odp

Spec:

    {
      "theme": {"background": "#ffffff", "text": "#1f2933", "accent": "#2b6cb0", "font": "Liberation Sans"},
      "slides": [
        {"title": "Quarterly review", "subtitle": "Q3 2026"},
        {"title": "Highlights",
         "bullets": ["Revenue up 12%", ["EU +18%", "US +7%"], "Two new customers"],
         "notes": "Mention the EU launch."},
        {"title": "Architecture", "image": "/workspace/out/diagram.png", "text": "Optional caption"},
        {"title": "Numbers", "bullets": ["Left side"], "image": "/workspace/out/chart.png"}
      ]
    }

A slide with only "title" (and optional "subtitle") is a title slide. "bullets"
is a list of strings; a nested list holds sub-bullets of the item before it.
"text" is a plain paragraph (or a list of them). "image" is a PNG or JPEG;
with bullets it goes on the right half, alone it's centred. "notes" are
speaker notes. Slides are 16:9 (28 x 15.75 cm).
"""

import json
import struct
import sys
from pathlib import Path

from odf.draw import Frame, Image, Page, TextBox
from odf.opendocument import OpenDocumentPresentation
from odf.presentation import Notes
from odf.style import (DrawingPageProperties, GraphicProperties, ListLevelProperties, MasterPage, PageLayout,
                       PageLayoutProperties, ParagraphProperties, Style, TextProperties)
from odf.text import List, ListItem, ListLevelStyleBullet, ListStyle, P

W, H, M = 28.0, 15.75, 1.5  # slide width, height and margin in cm


def image_size(path):
    """(width, height) in pixels of a PNG or JPEG, read from its header."""
    data = Path(path).read_bytes()
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return struct.unpack(">II", data[16:24])
    if data[:2] == b"\xff\xd8":
        i = 2
        while i < len(data):
            marker, size = data[i + 1], struct.unpack(">H", data[i + 2:i + 4])[0]
            if 0xC0 <= marker <= 0xCF and marker not in (0xC4, 0xC8, 0xCC):
                h, w = struct.unpack(">HH", data[i + 5:i + 9])
                return w, h
            i += 2 + size
    raise ValueError(f"{path}: only PNG and JPEG images are supported")


class Deck:
    def __init__(self, theme):
        t = {"background": "#ffffff", "text": "#1f2933", "accent": "#2b6cb0", "font": "Liberation Sans", **theme}
        self.doc = doc = OpenDocumentPresentation()
        layout = PageLayout(name="PL")
        layout.addElement(PageLayoutProperties(margin="0cm", pagewidth=f"{W}cm", pageheight=f"{H}cm",
                                               printorientation="landscape"))
        doc.automaticstyles.addElement(layout)
        bg = Style(name="DP", family="drawing-page")
        bg.addElement(DrawingPageProperties(fill="solid", fillcolor=t["background"]))
        doc.automaticstyles.addElement(bg)
        self.page_style = bg
        self.master = MasterPage(name="Default", pagelayoutname=layout)
        doc.masterstyles.addElement(self.master)

        self.frame = Style(name="Box", family="graphic")
        self.frame.addElement(GraphicProperties(stroke="none", fill="none", autogrowheight="false",
                                                textareaverticalalign="top", padding="0.1cm"))
        doc.automaticstyles.addElement(self.frame)
        self.image = Style(name="Img", family="graphic")
        self.image.addElement(GraphicProperties(stroke="none", fill="none"))
        doc.automaticstyles.addElement(self.image)

        # Text formatting goes on paragraph styles: presentation frames ignore it on the frame's style.
        def para_style(name, size, color, bold=False, align="start", space=0.0):
            s = Style(name=name, family="paragraph")
            s.addElement(ParagraphProperties(textalign=align, margintop=f"{space}cm", marginbottom=f"{space}cm"))
            s.addElement(TextProperties(fontsize=f"{size}pt", color=color, fontfamily=t["font"],
                                        fontweight="bold" if bold else "normal"))
            doc.automaticstyles.addElement(s)
            return s

        self.title = para_style("Title", 32, t["accent"], bold=True)
        self.cover = para_style("Cover", 44, t["accent"], bold=True, align="center")
        self.subtitle = para_style("Subtitle", 24, t["text"], align="center")
        self.body = para_style("Body", 20, t["text"], space=0.15)

        self.bullets = ListStyle(name="Bullets")
        for level, char in enumerate("•–▪", 1):
            b = ListLevelStyleBullet(level=level, bulletchar=char)
            b.addElement(ListLevelProperties(spacebefore=f"{(level - 1) * 0.9}cm", minlabelwidth="0.7cm"))
            self.bullets.addElement(b)
        doc.automaticstyles.addElement(self.bullets)

    def box(self, page, x, y, w, h, cls, *paragraphs):
        # presentation:class; "class" is a Python keyword.
        f = Frame(stylename=self.frame, x=f"{x:.2f}cm", y=f"{y:.2f}cm", width=f"{w:.2f}cm", height=f"{h:.2f}cm",
                  **{"class": cls})
        tb = TextBox()
        for p in paragraphs:
            tb.addElement(p)
        f.addElement(tb)
        page.addElement(f)

    def bullet_list(self, items):
        lst, last = List(stylename=self.bullets), None
        for item in items:
            if isinstance(item, list):
                if last is None:
                    last = ListItem()
                    lst.addElement(last)
                last.addElement(self.bullet_list(item))
            else:
                last = ListItem()
                last.addElement(P(stylename=self.body, text=str(item)))
                lst.addElement(last)
        return lst

    def picture(self, page, path, x, y, w, h):
        pw, ph = image_size(path)
        scale = min(w / pw, h / ph)
        iw, ih = pw * scale, ph * scale
        href = self.doc.addPicture(str(path))
        f = Frame(stylename=self.image, x=f"{x + (w - iw) / 2:.2f}cm", y=f"{y + (h - ih) / 2:.2f}cm",
                  width=f"{iw:.2f}cm", height=f"{ih:.2f}cm")
        f.addElement(Image(href=href))
        page.addElement(f)

    def slide(self, n, s):
        # draw:name is escaped by odfpy (spaces become _20_), so keep the default plain.
        page = Page(name=s.get("name") or f"slide{n}", masterpagename=self.master, stylename=self.page_style)
        self.doc.presentation.addElement(page)
        texts = s.get("text") or []
        texts = [texts] if isinstance(texts, str) else texts
        bullets, image = s.get("bullets"), s.get("image")
        full = W - 2 * M
        if not (texts or bullets or image):
            self.box(page, M, H * 0.3, full, 3, "title", P(stylename=self.cover, text=s.get("title", "")))
            if s.get("subtitle"):
                self.box(page, M, H * 0.3 + 3.2, full, 2, "subtitle", P(stylename=self.subtitle, text=s["subtitle"]))
        else:
            self.box(page, M, 0.8, full, 2, "title", P(stylename=self.title, text=s.get("title", "")))
            top = 3.2
            body = [P(stylename=self.body, text=t) for t in texts] + ([self.bullet_list(bullets)] if bullets else [])
            if bullets and image:  # bullets left, image right
                half = full / 2 - 0.5
                self.box(page, M, top, half, H - top - M, "outline", *body)
                self.picture(page, image, M + half + 1, top, half, H - top - M)
            elif image:  # caption above, image below
                if body:
                    self.box(page, M, top, full, 1.4 * len(body), "outline", *body)
                    top += 1.4 * len(body) + 0.3
                self.picture(page, image, M, top, full, H - top - M)
            else:
                self.box(page, M, top, full, H - top - M, "outline", *body)
        if s.get("notes"):
            notes = Notes()
            tb = TextBox()
            f = Frame(**{"class": "notes"}, x="2cm", y="14cm", width="17cm", height="11cm")
            f.addElement(tb)
            tb.addElement(P(text=s["notes"]))
            notes.addElement(f)
            page.addElement(notes)


def main(spec_path, out):
    spec = json.load(open(spec_path))
    deck = Deck(spec.get("theme", {}))
    for n, s in enumerate(spec["slides"], 1):
        deck.slide(n, s)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    deck.doc.save(str(out))
    print(f"wrote {out} ({len(spec['slides'])} slides)")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(*sys.argv[1:])
