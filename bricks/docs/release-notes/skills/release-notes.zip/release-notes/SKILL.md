---
name: release-notes
description: Writes user-facing release notes from a list of changes. Use when asked for release notes, a changelog entry or a "what's new" summary.
---

# Release notes

1. Read `template.md` in this skill's folder (Skill tool, `file: template.md`) and follow its layout exactly.
2. Sort every change into one section: **New**, **Improved** or **Fixed**. Leave out sections with no changes.
3. Write each change as one line in plain language for users: what they can do now, not how it was built. No commit hashes, ticket numbers or internal names.
4. Start each line with a verb in the past tense ("Added", "Made", "Fixed").
5. Keep the summary sentence under 25 words.
