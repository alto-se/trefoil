"""Fills {{placeholders}} in an OpenDocument file (.odt, .ods or .odp) and saves a copy.

    /opt/odf/bin/python fill_template.py template.odt values.json out.odt

values.json maps placeholder names to text: {"name": "Ada", "date": "2026-10-22"}.
Placeholders are replaced in the body, tables, headers and footers, keeping
the formatting of the text around them. A placeholder that Writer split
across differently formatted runs is still found, but then that paragraph
takes the formatting of its first run. A newline in a value becomes a line
break. Placeholders left without a value are listed on stderr and make the
script exit 1 (the file is still written).
"""

import json
import re
import sys

from odf import text
from odf.element import Element, Text
from odf.opendocument import load

PLACEHOLDER = re.compile(r"\{\{\s*([\w.-]+)\s*\}\}")


def text_nodes(el):
    for child in el.childNodes:
        if child.nodeType == Element.TEXT_NODE:
            yield child
        elif child.qname != (text.TEXTNS, "note"):
            yield from text_nodes(child)


def replace(match, values, missing):
    key = match[1]
    if key in values:
        return str(values[key])
    missing.add(key)
    return match[0]


def set_text(node, value):
    """Sets a text node's text, turning newlines into <text:line-break/>."""
    parts = value.split("\n")
    node.data = parts[0]
    parent, after = node.parentNode, node.nextSibling
    for part in parts[1:]:
        for new in (text.LineBreak(), Text(part)):
            if after is None:
                parent.appendChild(new)
            else:
                parent.insertBefore(new, after)


def fill_paragraph(p, values, missing):
    nodes = list(text_nodes(p))
    found = len(PLACEHOLDER.findall("".join(n.data for n in nodes)))
    if not found:
        return
    sub = lambda m: replace(m, values, missing)
    if sum(len(PLACEHOLDER.findall(n.data)) for n in nodes) == found:
        # Every placeholder sits inside one text node: replace in place, formatting kept.
        for n in nodes:
            if PLACEHOLDER.search(n.data):
                set_text(n, PLACEHOLDER.sub(sub, n.data))
        return
    # A placeholder spans runs: put the paragraph's filled text in its first node.
    filled = PLACEHOLDER.sub(sub, "".join(n.data for n in nodes))
    for n in nodes[1:]:
        n.data = ""
    set_text(nodes[0], filled)


def main(template, values_path, out):
    values = json.load(open(values_path))
    doc = load(template)
    missing = set()
    for root in (doc.body, doc.masterstyles, doc.automaticstyles):
        for kind in (text.P, text.H):
            for p in root.getElementsByType(kind):
                fill_paragraph(p, values, missing)
    doc.save(out)
    print(f"wrote {out}")
    if missing:
        print("no value for: " + ", ".join(sorted(missing)), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    main(*sys.argv[1:])
