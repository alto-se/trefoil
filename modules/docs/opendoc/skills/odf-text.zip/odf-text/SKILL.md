---
name: odf-text
description: Writes and edits OpenDocument text documents (.odt), and Word (.docx) or PDF documents made from them. Use when asked for a report, letter, memo, contract, offer or any other written document as a file, or to fill in a document template.
---

# OpenDocument text documents

Tools from the `docs:opendoc` module: `CreateDocument`, `ReadDocument`, `ConvertDocument`. Scripts in this skill run with `/opt/odf/bin/python` (needs a shell tool such as `Bash`).

## New document: write HTML, then CreateDocument

1. Write the whole document as one HTML string and call `CreateDocument` with `path` ending in `.odt` (or `.docx` / `.pdf` for those formats directly).
2. LibreOffice imports this HTML well:
   - `<h1>`–`<h6>` become real headings (they show up in the navigator and a table of contents); `<p>`, `<b>`, `<i>`, `<u>`, `<a href>`, `<ul>`/`<ol>` (nested too), `<br>`, `<blockquote>`, `<pre>`.
   - Tables: `<table border="1" cellpadding="4" cellspacing="0">` with `<th>`/`<td>`, `colspan`, `rowspan`. Use the `border` attribute: CSS borders are ignored.
   - CSS in a `<style>` block or `style=""`: `font-family`, `font-size`, `color`, `background`, `text-align`, `margin`. Use fonts that are installed: `Liberation Sans`, `Liberation Serif`, `Liberation Mono`, `DejaVu Sans`.
   - Page size and margins: `@page { size: 21cm 29.7cm; margin: 2.5cm }` (A4; US Letter is `21.59cm 27.94cm`).
   - Page breaks: `<p style="page-break-before: always">`.
   - Images: `<img src="/absolute/path.png" width="400" height="240">`. Local paths are embedded into the file automatically. Always give both `width` and `height` (pixels) in the image's aspect ratio.
3. Not supported through HTML: headers/footers, page numbers, footnotes, tracked changes, fields. For those, fill a template (below) or build the file with odfpy.

Keep the structure semantic: one `<h1>` title, `<h2>` sections, real lists and tables, not paragraphs that look like them.

## Template: fill {{placeholders}}

When the user gives a template (`.odt`, or `.docx` converted with `ConvertDocument format=odt` first), put the values in a JSON file and run:

```sh
/opt/odf/bin/python /trefoil/skills/odf-text/scripts/fill_template.py template.odt values.json out.odt
```

It replaces `{{name}}` in body, tables, headers and footers and keeps formatting. Exit code 1 lists placeholders that got no value: fix and rerun rather than leaving `{{...}}` in the output. Newlines in values become line breaks. Works for `.ods` and `.odp` templates too.

## Editing an existing document

- `ReadDocument` gives the text as Markdown-like lines (headings `#`, lists `-`, tables `| a | b |`), for odt, docx, doc, rtf.
- Small text changes that must keep the original styling: write a short odfpy script that loads the file, changes the text nodes and saves (`fill_template.py` shows how to walk them), rather than recreating the document.
- Large rewrites: read it, write new HTML with the changes, `CreateDocument`. Tell the user that original styling was not kept.

## Check before handing over

1. `ReadDocument` the result: all sections present, no `{{`, no HTML tags in the text.
2. `ConvertDocument format=pdf` and check the page count is sensible.
3. Save the files the user asked for (e.g. with `SaveArtifact`), usually the `.odt` plus a `.pdf` when they'll share it.
