---
name: odf-spreadsheet
description: Creates and reads OpenDocument spreadsheets (.ods), and Excel (.xlsx) or CSV files from them, with typed cells, formulas, currencies, dates and several sheets. Use when asked for a spreadsheet, budget, table of numbers, calculation sheet or data export, or to read numbers out of one.
---

# OpenDocument spreadsheets

Tools from the `docs:opendoc` module: `CreateDocument`, `ReadDocument`, `ConvertDocument`. Scripts in this skill run with `/opt/odf/bin/python` (needs a shell tool such as `Bash`).

## Plain data: CSV

A single table of values with no formulas or formatting: `CreateDocument` with `path` ending in `.ods` or `.xlsx` and the CSV as `content` (comma separated, `"` quoting, first row as header). Numbers are recognised; dates stay text, so use the spec below when dates matter.

## Anything more: JSON spec + make_ods.py

Write a spec and run:

```sh
/opt/odf/bin/python /trefoil/skills/odf-spreadsheet/scripts/make_ods.py spec.json out.ods
```

```json
{"sheets": [
  {"name": "Budget", "columns": [5, 3, 3], "header": true, "rows": [
    ["Item", "Cost", "Share"],
    ["Rent", {"currency": 12000, "code": "SEK"}, {"formula": "=B2/B$5", "type": "percent"}],
    ["Food", {"currency": 4500, "code": "SEK"}, {"formula": "=B3/B$5", "type": "percent"}],
    ["Other", {"currency": 2000, "code": "SEK"}, {"formula": "=B4/B$5", "type": "percent"}],
    ["Total", {"formula": "=SUM(B2:B4)", "type": "currency", "code": "SEK"}, {"formula": "=SUM(C2:C4)", "type": "percent"}]
  ]}
]}
```

- Cells: string, number, `true`/`false`, `null`, or an object: `{"text"}`, `{"number"}`, `{"currency", "code"}`, `{"percent": 0.25}` (a fraction), `{"date": "YYYY-MM-DD"}`, `{"formula", "type"}`; any of them can add `"bold": true`.
- A string starting with `=` is a formula. Write them like in Excel: `=SUM(B2:B4)`, `=Sheet2!A1`, `='My sheet'!A1`, `=IF(A1>0,"yes","no")`, absolute refs with `$`. The script translates them to OpenFormula and LibreOffice then calculates them, so the file has values.
- Give a formula a `type` (`currency`, `percent`, `date`) when its result should be formatted that way.
- `columns`: widths in cm. `header: true` makes the first row bold.
- Keep raw inputs in cells and compute totals with formulas rather than typing computed numbers, so the user can change inputs.

## Reading and exporting

- `ReadDocument` on `.ods`, `.xlsx`, `.xls` or `.csv` shows each sheet as `| a | b |` rows; formula cells show the value then `{of:=...}`.
- `ConvertDocument format=xlsx` for Excel users; `format=csv` writes one CSV per sheet (`<file>-<sheet>.csv`); `format=pdf` prints it.

## Check before handing over

`ReadDocument` the result: totals are numbers (not `0` or `Err:...`/`#NAME?`), currencies and dates show formatted, every sheet is there. Then save what the user asked for (e.g. `SaveArtifact`).
