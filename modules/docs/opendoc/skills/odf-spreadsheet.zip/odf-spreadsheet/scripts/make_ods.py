"""Builds an OpenDocument spreadsheet (.ods) from a JSON spec.

    /opt/odf/bin/python make_ods.py spec.json out.ods

Spec:

    {
      "sheets": [
        {
          "name": "Sales",
          "columns": [4, 2.5, 3],          # optional column widths in cm
          "header": true,                  # optional: bold first row
          "rows": [
            ["Item", "Qty", "Price", "Total"],
            ["Apple", 3, {"currency": 1.5}, "=B2*C2"],
            ["Pear", 4, {"currency": 2}, "=B3*C3"],
            ["Sum", "=SUM(B2:B3)", "", "=SUM(D2:D3)"],
            ["Date", {"date": "2026-10-22"}, {"percent": 0.25}, true]
          ]
        }
      ]
    }

Cells: a string (text; a leading "=" makes it a formula), a number, true/false,
null (empty), or an object: {"text": ...}, {"number": ...}, {"currency": ...,
"code": "EUR"}, {"percent": 0.25}, {"date": "YYYY-MM-DD"}, {"formula": "=...",
"type": "number|currency|percent|date|text"}, plus optional "bold": true.
Formulas use spreadsheet syntax (=SUM(B2:B3), =Other!A1, =IF(A1>0,"y","n"));
they're translated to OpenFormula. The file is then opened and saved once
with LibreOffice so formula cells hold their calculated values.
"""

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from odf.number import CurrencyStyle, CurrencySymbol, DateStyle, Day, Month, Number, NumberStyle, PercentageStyle, Text, Year
from odf.opendocument import OpenDocumentSpreadsheet
from odf.style import Style, TableColumnProperties, TextProperties
from odf.table import Table, TableCell, TableColumn, TableRow
from odf.text import P

REF = re.compile(r"(?<![\w.$])(?:(?P<sheet>'[^']+'|[A-Za-z_][\w.]*)!)?(?P<a>\$?[A-Z]{1,3}\$?\d+)(?::(?P<b>\$?[A-Z]{1,3}\$?\d+))?(?![\w(])")


def formula(expr):
    """Spreadsheet-style formula -> OpenFormula: =SUM(B2:B3) -> of:=SUM([.B2:.B3])."""
    out = []
    for part in re.split(r'("(?:[^"]|"")*")', expr.lstrip("=")):
        if part.startswith('"'):
            out.append(part)
            continue

        def ref(m):
            sheet = m["sheet"] or ""
            if sheet:
                sheet = "$" + (sheet if sheet.startswith("'") else sheet)
            r = f"{sheet}.{m['a']}"
            if m["b"]:
                r += f":{sheet}.{m['b']}" if sheet else f":.{m['b']}"
            return f"[{r}]"

        out.append(REF.sub(ref, part).replace(",", ";"))
    return "of:=" + "".join(out)


class Book:
    def __init__(self):
        self.doc = OpenDocumentSpreadsheet()
        self.data, self.cells = {}, {}

    def add(self, style, automatic=True):
        (self.doc.automaticstyles if automatic else self.doc.styles).addElement(style)
        return style

    def data_styles(self):
        if self.data:
            return self.data
        date = DateStyle(name="N-date")
        for el in (Year(style="long"), Text(text="-"), Month(style="long"), Text(text="-"), Day(style="long")):
            date.addElement(el)
        pct = PercentageStyle(name="N-pct")
        pct.addElement(Number(decimalplaces="1", minintegerdigits="1"))
        pct.addElement(Text(text="%"))
        num = NumberStyle(name="N-num")
        num.addElement(Number(decimalplaces="2", minintegerdigits="1", grouping="true"))
        for s in (date, pct, num):
            self.add(s)
        self.data = {"date": date, "percent": pct, "number": num}
        return self.data

    def cell_style(self, kind, bold, code="EUR"):
        key = (kind, bold, code if kind == "currency" else None)
        if key in self.cells:
            return self.cells[key]
        attrs = {"name": f"ce{len(self.cells)}", "family": "table-cell"}
        if kind == "currency":
            cur = CurrencyStyle(name=f"N-cur-{code}")
            cur.addElement(Number(decimalplaces="2", minintegerdigits="1", grouping="true"))
            cur.addElement(Text(text=" "))
            cur.addElement(CurrencySymbol(text=code))
            self.add(cur)
            attrs["datastylename"] = cur
        elif kind in ("date", "percent"):
            attrs["datastylename"] = self.data_styles()[kind]
        style = Style(**attrs)
        if bold:
            style.addElement(TextProperties(fontweight="bold"))
        self.cells[key] = self.add(style)
        return style

    def cell(self, v, bold=False):
        if v is None or v == "":
            return TableCell()
        if isinstance(v, bool):
            v = {"boolean": v}
        elif isinstance(v, (int, float)):
            v = {"number": v}
        elif isinstance(v, str):
            v = {"formula": v} if v.startswith("=") else {"text": v}
        bold = v.get("bold", bold)
        kw = {}
        if "formula" in v:
            kind = v.get("type", "number")
            kw["formula"] = formula(v["formula"])
            value = None
        else:
            kind = next(k for k in ("text", "number", "currency", "percent", "date", "boolean") if k in v)
            value = v[kind]
        if kind == "text":
            kw["valuetype"] = "string"
        elif kind == "date":
            kw["valuetype"] = "date"
            if value is not None:
                kw["datevalue"] = value
        elif kind == "boolean":
            kw["valuetype"] = "boolean"
            kw["booleanvalue"] = "true" if value else "false"
        else:
            kw["valuetype"] = {"number": "float", "currency": "currency", "percent": "percentage"}[kind]
            if kind == "currency":
                kw["currency"] = v.get("code", "EUR")
            if value is not None:
                kw["value"] = value
        if bold or kind in ("currency", "date", "percent"):
            kw["stylename"] = self.cell_style(kind, bold, v.get("code", "EUR"))
        c = TableCell(**kw)
        if value is not None:
            c.addElement(P(text=str(value).upper() if kind == "boolean" else str(value)))
        return c

    def sheet(self, spec):
        t = Table(name=spec["name"])
        for i, width in enumerate(spec.get("columns", [])):
            s = self.add(Style(name=f"co{spec['name']}{i}".replace(" ", "_"), family="table-column"))
            s.addElement(TableColumnProperties(columnwidth=f"{width}cm"))
            t.addElement(TableColumn(stylename=s))
        for r, row in enumerate(spec.get("rows", [])):
            tr = TableRow()
            for v in row:
                tr.addElement(self.cell(v, bold=spec.get("header") and r == 0))
            t.addElement(tr)
        self.doc.spreadsheet.addElement(t)


def recalc(path):
    """Round-trips the file through LibreOffice, which stores each formula's calculated value."""
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(["soffice", f"-env:UserInstallation=file://{tmp}/profile", "--headless", "--norestore",
                        "--convert-to", "ods", "--outdir", f"{tmp}/out", str(path)],
                       check=True, capture_output=True, timeout=180)
        shutil.move(f"{tmp}/out/{path.name}", path)


def main(spec_path, out):
    spec = json.load(open(spec_path))
    book = Book()
    for s in spec["sheets"]:
        book.sheet(s)
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    book.doc.save(str(out))
    if shutil.which("soffice"):
        recalc(out)
    print(f"wrote {out}")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(*sys.argv[1:])
