---
name: proofread
description: Proofreads a text and writes a short report of spelling, grammar and style issues. Use when asked to proofread, copy-edit or review the writing of a text.
---

# Proofread

1. Run `TextStats` and `SpellCheck` on the text. Words `SpellCheck` flags may be names or jargon; only report ones that look like typos.
2. Read the text yourself for grammar and style, using `checklist.md` in this skill's folder (Skill tool, `file: checklist.md`).
3. Write the report in this layout:

```markdown
# Proofreading report

_Checked <date and time from the Now tool>_

| Words | Sentences | Reading time |
|---|---|---|
| … | … | … |

## Issues

- **"<quote>"** → "<fix>" — <why, a few words>

## Verdict

<one sentence>
```

List at most 15 issues, most important first. If there are none, write "No issues found." under Issues.
