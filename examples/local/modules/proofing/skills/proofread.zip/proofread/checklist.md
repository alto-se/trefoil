# Checklist

- Subject–verb agreement ("the list of items are" → "is")
- Its / it's, their / there / they're, your / you're, then / than
- Repeated words ("the the")
- Sentences over 30 words: suggest a split
- Passive voice where the actor matters
- Filler: "very", "really", "basically", "in order to"
- Inconsistent spelling of the same name or term
